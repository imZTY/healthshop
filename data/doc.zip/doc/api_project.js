define({
  "name": "HealthShop data API",
  "version": "0.0.3",
  "description": "The data API of our team in the Course named fucking MI.",
  "title": "HealthShop API",
  "url": "https://zengtianyi.top/health",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-11-27T05:56:42.682Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
