define({
  "name": "HealthShop data API",
  "version": "0.0.4",
  "description": "The data API of our team in the Course named fucking MI.",
  "title": "HealthShop API",
  "url": "https://zengtianyi.top/health",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-11-30T16:14:45.964Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
